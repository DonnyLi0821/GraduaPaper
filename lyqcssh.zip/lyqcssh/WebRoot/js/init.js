$(function(){
	
	$('.socials').mobilyblocks();
	
	$('.nature').mobilyblocks({
		trigger: 'hover',
		direction: 'counter',
		duration:500,
		zIndex:50,
		widthMultiplier:1.15
	});
	
});
